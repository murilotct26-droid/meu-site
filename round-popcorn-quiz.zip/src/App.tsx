/**
 * Round Popcorn Quiz Clone - Exact replication of https://www.roundpops.site/
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { quizSteps, UnlockBonus } from './quizConfig.ts';
import { startAmbientAudio, stopAmbientAudio, unlockAudio, playChimeSound } from './audio.ts';
import { Header } from './components/Header.tsx';
import { PopcornConfetti } from './components/PopcornConfetti.tsx';
import { RewardBanner } from './components/RewardBanner.tsx';
import { StepRenderer } from './components/StepRenderer.tsx';
import { LandingPage } from './components/LandingPage.tsx';

export default function App() {
  const [stepIndex, setStepIndex] = useState<number>(0);
  const [unlockedGifts, setUnlockedGifts] = useState<UnlockBonus[]>([]);
  const [activeBonusAlert, setActiveBonusAlert] = useState<UnlockBonus | null>(null);
  const [confettiTrigger, setConfettiTrigger] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [name, setName] = useState<string>('');
  const [pulse, setPulse] = useState<boolean>(false);
  const [lastDelta, setLastDelta] = useState<number | null>(null);

  const answeredIdsRef = useRef<Set<string>>(new Set());
  const isTransitioningRef = useRef<boolean>(false);

  const currentStep = quizSteps[stepIndex] || quizSteps[0];

  // Steps that count toward quiz completion
  const measurableSteps = useMemo(
    () => quizSteps.filter((s) => s.kind !== 'intro' && s.kind !== 'result'),
    []
  );

  const measurableIndex = useMemo(
    () => measurableSteps.findIndex((s) => s.id === currentStep.id),
    [measurableSteps, currentStep.id]
  );

  const totalBonus = useMemo(
    () => unlockedGifts.reduce((acc, g) => acc + g.value, 0),
    [unlockedGifts]
  );

  // Scroll to top on step changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentStep.id]);

  // Unlock audio system on first interaction
  useEffect(() => {
    const handleGlobalInteraction = async () => {
      await unlockAudio();
      await startAmbientAudio();
    };

    window.addEventListener('click', handleGlobalInteraction, { passive: true });
    window.addEventListener('touchstart', handleGlobalInteraction, { passive: true });
    window.addEventListener('keydown', handleGlobalInteraction, { passive: true });

    return () => {
      window.removeEventListener('click', handleGlobalInteraction);
      window.removeEventListener('touchstart', handleGlobalInteraction);
      window.removeEventListener('keydown', handleGlobalInteraction);
      stopAmbientAudio();
    };
  }, []);

  // Stop ambient audio once on final result page
  useEffect(() => {
    if (currentStep.kind === 'result') {
      stopAmbientAudio();
    }
  }, [currentStep.kind]);

  // Advance step logic and trigger rewards
  const handleAdvanceStep = (stepObj = currentStep, customNextId?: string) => {
    // Check if this step unlocks a reward
    if (stepObj.unlocks && !answeredIdsRef.current.has(stepObj.unlocks.id)) {
      answeredIdsRef.current.add(stepObj.unlocks.id);
      const bonus = stepObj.unlocks;

      setLastDelta(bonus.value);
      setUnlockedGifts((prev) =>
        prev.some((g) => g.id === bonus.id) ? prev : [...prev, bonus]
      );
      setActiveBonusAlert(bonus);
      playChimeSound();
      setConfettiTrigger((prev) => prev + 1);
      setPulse(true);
      setTimeout(() => setPulse(false), 900);
    }

    let nextIdx = stepIndex + 1;
    if (customNextId) {
      const foundIdx = quizSteps.findIndex((s) => s.id === customNextId);
      if (foundIdx !== -1) {
        nextIdx = foundIdx;
      }
    }

    setStepIndex(Math.min(nextIdx, quizSteps.length - 1));
  };

  const handleAnswer = (stepId: string, optionId: string, goTo?: string) => {
    if (isTransitioningRef.current) return;
    isTransitioningRef.current = true;

    setAnswers((prev) => ({ ...prev, [stepId]: optionId }));

    setTimeout(() => {
      isTransitioningRef.current = false;
      handleAdvanceStep(currentStep, goTo);
    }, 220);
  };

  const handleLeadSubmit = () => {
    handleAdvanceStep(currentStep);
  };

  if (currentStep.kind === 'result') {
    return (
      <LandingPage
        name={name}
        quizTotal={totalBonus}
        quizGifts={unlockedGifts.map((g) => ({ title: g.title, value: g.value }))}
      />
    );
  }

  return (
    <main className="min-h-screen bg-background">
      <div className="min-h-screen w-full">
        {/* Confetti particles */}
        <PopcornConfetti trigger={confettiTrigger} />

        {/* Sticky top progress & rewards bar */}
        <Header
          total={totalBonus}
          current={measurableIndex > -1 ? measurableIndex : 0}
          steps={measurableSteps.length}
          pulse={pulse}
          unlockedCount={unlockedGifts.length}
          lastDelta={lastDelta}
        />

        {/* Top slide-down reward popup banner */}
        <RewardBanner
          bonus={activeBonusAlert}
          onDone={() => setActiveBonusAlert(null)}
        />

        {/* Step content container */}
        <div className="mx-auto w-full max-w-xl px-5 pb-8 pt-4">
          <div key={currentStep.id} className="animate-rise">
            <StepRenderer
              step={currentStep}
              answers={answers}
              name={name}
              onAnswer={handleAnswer}
              onNameChange={setName}
              onNext={() => handleAdvanceStep(currentStep)}
              onLeadSubmit={handleLeadSubmit}
            />
          </div>
        </div>
      </div>
    </main>
  );
}
