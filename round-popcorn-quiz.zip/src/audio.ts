/**
 * Robust Web Audio manager for Round Popcorn Quiz
 * Handles audio context unlock, ambient loop, reward chimes, and interactive click pops.
 */

let masterAudioCtx: AudioContext | null = null;
let ambientAudio: HTMLAudioElement | null = null;
let isAudioMuted: boolean = false;

function getOrCreateAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;

  if (!masterAudioCtx) {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      try {
        masterAudioCtx = new AudioContextClass();
      } catch (err) {
        console.warn('[Audio] Failed to instantiate AudioContext', err);
      }
    }
  }

  if (masterAudioCtx && masterAudioCtx.state === 'suspended') {
    masterAudioCtx.resume().catch(() => {});
  }

  return masterAudioCtx;
}

/**
 * Initializes and unlocks audio on first user touch/click
 */
export async function unlockAudio(): Promise<boolean> {
  const ctx = getOrCreateAudioContext();
  if (ctx && ctx.state === 'suspended') {
    try {
      await ctx.resume();
    } catch {
      // Ignored
    }
  }

  if (!isAudioMuted && !ambientAudio) {
    startAmbientAudio().catch(() => {});
  }

  return true;
}

/**
 * Start playing ambient background music loop
 */
export async function startAmbientAudio(): Promise<boolean> {
  if (typeof window === 'undefined' || isAudioMuted) return false;

  try {
    if (!ambientAudio) {
      const audio = new Audio('/assets/ambient-loop.mp3');
      audio.crossOrigin = 'anonymous';
      audio.loop = true;
      audio.preload = 'auto';
      audio.volume = 0.035; // Gentle pleasant background volume
      ambientAudio = audio;
    }

    const ctx = getOrCreateAudioContext();
    if (ctx && ctx.state === 'suspended') {
      await ctx.resume();
    }

    const promise = ambientAudio.play();
    if (promise !== undefined) {
      await promise;
    }
    return !ambientAudio.paused;
  } catch (err) {
    // Autoplay prevented until user gesture
    return false;
  }
}

/**
 * Stop ambient background music
 */
export function stopAmbientAudio(): void {
  if (ambientAudio) {
    try {
      ambientAudio.pause();
      ambientAudio.currentTime = 0;
    } catch {
      // Ignored
    }
  }
}

/**
 * Toggle audio mute state
 */
export function toggleMute(): boolean {
  isAudioMuted = !isAudioMuted;
  if (isAudioMuted) {
    if (ambientAudio) ambientAudio.pause();
  } else {
    if (ambientAudio) ambientAudio.play().catch(() => {});
  }
  return isAudioMuted;
}

export function getMuteState(): boolean {
  return isAudioMuted;
}

/**
 * Delightful click/pop sound when selecting quiz options
 */
export function playPopSound(): void {
  if (isAudioMuted) return;
  const ctx = getOrCreateAudioContext();
  if (!ctx) return;

  try {
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    // Frequency drops from 680Hz to 240Hz for a juicy bubble "pop"
    osc.frequency.setValueAtTime(680, now);
    osc.frequency.exponentialRampToValueAtTime(240, now + 0.08);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.1);
  } catch {
    // Audio context issue
  }
}

/**
 * Exact reward unlock chime synthesized via Web Audio:
 * Dual triangle waves (988Hz & 1319Hz) with an exponential decay envelope.
 */
export function playChimeSound(): void {
  if (isAudioMuted) return;
  const ctx = getOrCreateAudioContext();
  if (!ctx) return;

  try {
    const now = ctx.currentTime;
    const gain = ctx.createGain();

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.25, now + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.55);
    gain.connect(ctx.destination);

    const freqs = [988, 1319]; // B5 and E6 cheerful ascending interval
    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.09);
      osc.connect(gain);
      osc.start(now + idx * 0.09);
      osc.stop(now + 0.6);
    });
  } catch (err) {
    console.warn('[Audio] Chime playback failed', err);
  }
}
