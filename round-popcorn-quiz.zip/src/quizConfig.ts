export interface HeadlineHighlight {
  text: string;
  tone: 'gold' | 'danger' | 'accent';
}

export interface Option {
  id: string;
  label: string;
  emoji?: string;
  goTo?: string;
}

export interface UnlockBonus {
  id: string;
  title: string;
  value: number;
  emoji: string;
}

export interface CalculationRow {
  label: string;
  value: string;
  emoji: string;
  highlight?: boolean;
}

export interface ContentBlock {
  emoji: string;
  title: string;
  text: string;
}

export interface GalleryItem {
  image: string;
  title: string;
  text: string;
}

export interface TimelineItem {
  phase: string;
  title: string;
  subtitle: string;
  text: string;
  emoji: string;
  image?: string;
}

export interface VideoClipConfig {
  src: string;
  width: number;
  height: number;
  formats: string[];
}

export interface QuizStep {
  id: string;
  kind: 'intro' | 'form' | 'question' | 'retention' | 'content' | 'timeline' | 'loading' | 'result';
  greeting?: string;
  headline?: string;
  headlineHighlights?: HeadlineHighlight[];
  subline?: string;
  sublineHighlights?: HeadlineHighlight[];
  teaser?: string;
  cta?: string;
  footnote?: string;
  body?: string;
  eyebrow?: string;
  helper?: string;
  question?: string;
  options?: Option[];
  unlocks?: UnlockBonus;
  clip?: VideoClipConfig;
  image?: string;
  images?: string[];
  fields?: Array<{
    id: string;
    label: string;
    placeholder: string;
    type: string;
    autoComplete?: string;
  }>;
  disclaimer?: string;
  calculation?: CalculationRow[];
  bullets?: string[];
  blocks?: ContentBlock[];
  galleryTitle?: string;
  gallery?: GalleryItem[];
  items?: TimelineItem[];
  messages?: string[];
  durationMs?: number;
  videoUrl?: string;
  ctaHref?: string;
  urgency?: string;
}

export interface LevelThreshold {
  at: number;
  name: string;
  emoji: string;
}

export const quizLevels: LevelThreshold[] = [
  { at: 0, name: 'Rookie', emoji: '🌽' },
  { at: 15, name: 'Popper', emoji: '🍿' },
  { at: 40, name: 'Gourmet', emoji: '👩‍🍳' },
  { at: 70, name: 'Boss Lady', emoji: '🏆' },
];

export function getLevelForScore(score: number): LevelThreshold {
  let current = quizLevels[0];
  for (const level of quizLevels) {
    if (score >= level.at) {
      current = level;
    }
  }
  return current;
}

export const quizSteps: QuizStep[] = [
  {
    id: "intro",
    kind: "intro",
    greeting: "",
    headline: "Why Are Some Women Making $150 in 1 Hour, While Others Work Exhausting for $15/Hour or Live on a Retirement Check That Barely Covers the Rent?",
    headlineHighlights: [
      { text: "$150 in 1 Hour", tone: "gold" },
      { text: "$15/Hour", tone: "danger" }
    ],
    clip: {
      src: "/assets/intro-loop",
      width: 568,
      height: 320,
      formats: ["mp4"]
    },
    subline: "Answer the questions and discover how round popcorn became a simple and dignified way to make money from home. At the end, you’ll unlock free gifts to learn the step-by-step process and start today.",
    sublineHighlights: [
      { text: "round popcorn", tone: "accent" }
    ],
    teaser: "How to claim your gifts: answer the questions below in less than 3 minutes. Every answer earns you points and unlocks your exclusive access at the end!",
    cta: "I want my gifts",
    footnote: "Takes less than 3 minutes"
  },
  {
    id: "nome",
    kind: "form",
    headline: "What name should we put on your gift?",
    body: "",
    fields: [
      {
        id: "nome",
        label: "Your first name",
        placeholder: "Type your first name",
        type: "text",
        autoComplete: "given-name"
      }
    ],
    cta: "Continue",
    unlocks: {
      id: "b1",
      title: "Gift reserved in your name",
      value: 4,
      emoji: "🎁"
    }
  },
  {
    id: "q_experiencia_artesanal",
    kind: "question",
    question: "{nome}, have you ever worked with artisanal products like gourmet popcorn or similar treats before?",
    options: [
      { id: "profissional", label: "Yes, I am already a professional.", emoji: "👩‍🍳" },
      { id: "hobby-renda", label: "Yes, I make them as a hobby or for extra income.", emoji: "🧁" },
      { id: "quero-aprender", label: "No, but I want to learn so I can start making money.", emoji: "💡" },
      { id: "so-hobby", label: "No, I just want to learn for fun as a hobby.", emoji: "🫖" }
    ],
    unlocks: {
      id: "b2",
      title: "Getting started guide",
      value: 6,
      emoji: "📘"
    }
  },
  {
    id: "q_regiao",
    kind: "question",
    question: "What kind of area do you currently live in?",
    options: [
      { id: "capital", label: "Big city or metropolis", emoji: "🏙" },
      { id: "media", label: "Mid-sized city or suburb", emoji: "🌆" },
      { id: "pequena", label: "Small town", emoji: "🏘" },
      { id: "rural", label: "Rural area or countryside", emoji: "🌄" }
    ]
  },
  {
    id: "r_regiao",
    kind: "retention",
    headline: "Perfect! You hit the jackpot with your area, {nome} 📍",
    body: "Here's why: Customers around there love unique, handmade treats. With a premium product that practically sells itself, you have the potential to make at least $600 a week at local events, craft fairs, or just right in your neighborhood!",
    clip: {
      src: "/assets/craft-fair",
      width: 692,
      height: 388,
      formats: ["mp4"]
    },
    cta: "Continue",
    unlocks: {
      id: "b3",
      title: "Local selling map",
      value: 8,
      emoji: "📍"
    }
  },
  {
    id: "q_renda",
    kind: "question",
    question: "Are you currently working or making an income?",
    options: [
      { id: "nao", label: "No, I'm not.", emoji: "🚫" },
      { id: "sim", label: "Yes, I have a job.", emoji: "✅" },
      { id: "bicos", label: "I just do some side hustles.", emoji: "🔁" }
    ]
  },
  {
    id: "q_situacao",
    kind: "question",
    question: "{nome}, which of these best describes your current situation?",
    options: [
      { id: "renda-extra", label: "I have a job, but I need extra cash to help pay the bills.", emoji: "💸" },
      { id: "liberdade", label: "I'm burnt out at work and want more freedom and flexibility.", emoji: "🕊" },
      { id: "urgente", label: "I'm currently out of work and urgently need a fast way to make money.", emoji: "⚡" },
      { id: "tranquila", label: "I'm financially comfortable, just looking for a fun hobby.", emoji: "🌿" }
    ],
    unlocks: {
      id: "b4",
      title: "Personalized income plan",
      value: 9,
      emoji: "🗺"
    }
  },
  {
    id: "q_experiencia_pipoca",
    kind: "question",
    question: "What's your experience level with making gourmet round popcorn?",
    options: [
      { id: "zero", label: "I'm a complete beginner, no idea where to start.", emoji: "🤷‍♀️" },
      { id: "vi", label: "I've seen how it's made, but never tried it myself.", emoji: "👀" },
      { id: "errado", label: "I've tried a few times, but it never turns out right.", emoji: "😅" },
      { id: "pro", label: "I have experience, but I want to learn professional techniques.", emoji: "🎯" }
    ]
  },
  {
    id: "c_porque",
    kind: "content",
    headline: "Why Round Popcorn crushes regular treats (like cookies and cupcakes)",
    blocks: [
      {
        emoji: "⏳",
        title: "Lasts 20 Days",
        text: "Make a batch in one single day and have inventory to sell all week long, without worrying about it going stale or getting soggy."
      },
      {
        emoji: "🎓",
        title: "Super Easy to Learn",
        text: "Quick, foolproof techniques. You don't even need to know how to cook to start seeing profits in your very first week."
      },
      {
        emoji: "🛒",
        title: "Simple Ingredients",
        text: "Everything you need is at your local grocery store (or one click away online). No expensive equipment needed."
      },
      {
        emoji: "🛍",
        title: "Sell It Your Way",
        text: "Start by selling to your neighbors, land massive orders for parties, or build your own premium brand."
      },
      {
        emoji: "⚡",
        title: "Lightning-Fast Production",
        text: "Make dozens of luxurious bags all at once using just the regular pan you already have in your kitchen."
      },
      {
        emoji: "🎯",
        title: "Zero Competition",
        text: "Dominate Instagram, craft fairs, or delivery apps and make up to 4x more profit than traditional bakers."
      }
    ],
    cta: "Makes sense, continue",
    unlocks: {
      id: "b5",
      title: "Class: why round popcorn sells",
      value: 11,
      emoji: "🍿"
    }
  },
  {
    id: "c_calculo",
    kind: "content",
    headline: "{nome}, here is a simple breakdown so you can see the true power of round popcorn",
    calculation: [
      { label: "Cost to make", value: "$0.90 to $1.50 per bag", emoji: "🛒" },
      { label: "Typical selling price", value: "$8 to $15", emoji: "🏷️" },
      { label: "Pure profit per bag", value: "$7 to $13", emoji: "💰" },
      { label: "Selling 10 bags a day (at $12)", value: "$120 a day", emoji: "📅" },
      { label: "In 25 days x $120", value: "$3,000 a month!", highlight: true, emoji: "🚀" }
    ],
    body: "In this example, you cooked everything on just 1 day of the week and only focused on selling the rest of the time. And this is a very realistic calculation, not even counting huge bulk orders for parties and events!",
    cta: "I want these results"
  },
  {
    id: "q_curso",
    kind: "question",
    question: "Have you ever taken an online course before?",
    options: [
      { id: "terminei", label: "Yes, and I completely finished it.", emoji: "🏆" },
      { id: "nao-terminei", label: "I started one, but never finished it.", emoji: "🌀" },
      { id: "nunca", label: "No, I've never taken one.", emoji: "🆕" }
    ],
    unlocks: {
      id: "b6",
      title: "Anti-mistake checklist",
      value: 8,
      emoji: "✅"
    }
  },
  {
    id: "q_apoio",
    kind: "question",
    question: "{nome}, as you go through this training, will you have anyone to support you emotionally or financially?",
    options: [
      { id: "sim", label: "Yes, absolutely.", emoji: "🤝" },
      { id: "talvez", label: "Maybe.", emoji: "🤔" },
      { id: "ninguem", label: "No, I am doing this completely on my own.", emoji: "💪" }
    ]
  },
  {
    id: "c_apoio",
    kind: "content",
    headline: "Don't worry! Our focus is to keep everything simple and easy to follow",
    body: "Even if you have little knowledge, zero experience, or no support system, you will never be alone in this. Here, you'll learn how to work right from your own kitchen, selling a premium treat that is worth 4x more than traditional baked goods.",
    bullets: [
      "Irresistible recipes that sell themselves: over 60 best-selling flavors.",
      "The 20-Day Crunch Secret: the exact technique to keep your popcorn perfectly crunchy for 20 days without going stale.",
      "Luxury Packaging: how to make your bags look so premium you can easily charge 4x more.",
      "Done-For-You Captions: a practical guide with ready-to-use posts — just copy, paste, and use every day.",
      "The Ultimate Party Guide: how to land huge bulk orders and make a month's salary in a single day.",
      "Business from Scratch: the step-by-step roadmap to start today and get your first customers in just 7 days."
    ],
    cta: "Continue",
    galleryTitle: "Bestsellers",
    gallery: [
      { image: "/assets/oreo.webp", title: "Oreo", text: "A worldwide classic that everyone loves" },
      { image: "/assets/kinderbueno.webp", title: "Kinder Bueno", text: "An exclusive flavor with a sophisticated twist" },
      { image: "/assets/nutella.webp", title: "Nutella", text: "Everyone's favorite hazelnut cream" },
      { image: "/assets/pink-lemonade.webp", title: "Pink Lemonade", text: "Refreshing, citrusy, and irresistible" },
      { image: "/assets/milk-cream.webp", title: "Milk Cream", text: "Smooth, creamy, and nostalgic" },
      { image: "/assets/salted-caramel.webp", title: "Salted Caramel", text: "The perfect balance of sweet and salty" }
    ],
    unlocks: {
      id: "b7",
      title: "The ultimate party guide",
      value: 16,
      emoji: "🎉"
    }
  },
  {
    id: "q_frase",
    kind: "question",
    question: "Which of these quotes best describes your current situation?",
    options: [
      { id: "independencia", label: "“I urgently need to build my financial independence so I can stop living paycheck to paycheck.”", emoji: "🔥" },
      { id: "negocio", label: "“I want a profitable business that is 100% mine so I never have to rely on anyone else's money.”", emoji: "👑" },
      { id: "reinvencao", label: "“I'm reinventing myself and want to prove I can be successful on my own terms.”", emoji: "🦋" },
      { id: "margem", label: "“I already work hard, but I need something with high profit margins to get my time freedom back.”", emoji: "⏱" }
    ]
  },
  {
    id: "q_primeiro_uso",
    kind: "question",
    question: "If you were making an extra $3,000 a month with round popcorn, what is the first thing you would do with that money, {nome}?",
    options: [
      { id: "demissao", label: "Quit my 9-to-5 job.", emoji: "🚪" },
      { id: "lojinha", label: "Open my own popcorn shop and work for myself.", emoji: "🏪" },
      { id: "contas", label: "Pay off my bills and finally achieve financial freedom.", emoji: "🧾" },
      { id: "guardaria", label: "Build a nest egg so I can retire peacefully on my own terms.", emoji: "🌅" }
    ],
    unlocks: {
      id: "b8",
      title: "Revenue goals plan",
      value: 11,
      emoji: "📈"
    }
  },
  {
    id: "c_objecao",
    kind: "timeline",
    headline: "Do I need any special skills, prior experience, or startup money? The answer is NO!",
    body: "With Carmela's method, you will learn the entire process step-by-step. You can start from absolute scratch, using only the tools you already have in your kitchen.",
    items: [
      {
        phase: "DAY 1",
        title: "Just one pan",
        subtitle: "START TODAY",
        text: "You start with what you already have in your kitchen, with no expensive equipment.",
        emoji: "🍳",
        image: "/assets/bullets1.webp"
      },
      {
        phase: "DAY 3",
        title: "No experience needed",
        subtitle: "ANYONE CAN DO IT",
        text: "Simple, straight-to-the-point lessons. In a few days you'll make your first perfect bags.",
        emoji: "👩‍🍳",
        image: "/assets/bullets2.webp"
      },
      {
        phase: "WEEK 1",
        title: "You set the price",
        subtitle: "A MARKET WITH NO COMPETITION",
        text: "You choose how much to charge. A handmade product with high perceived value and little competition.",
        emoji: "🏷️",
        image: "/assets/bullets3.webp"
      },
      {
        phase: "WEEK 2",
        title: "Sell through the apps",
        subtitle: "SALES WITHOUT LEAVING HOME",
        text: "Orders start coming in every day, straight from your kitchen to delivery apps.",
        emoji: "📦",
        image: "/assets/bullets4.webp"
      },
      {
        phase: "MONTH 1",
        title: "Large bulk orders",
        subtitle: "PARTIES, EVENTS, CORPORATE",
        text: "You start getting big orders for parties and events. That's when it becomes serious income.",
        emoji: "🎉",
        image: "/assets/bullets5.webp"
      }
    ],
    cta: "Got it, continue"
  },
  {
    id: "q_compromisso",
    kind: "question",
    question: "If you unlock these free gifts, do you promise to make the most of this opportunity?",
    options: [
      { id: "talvez", label: "Maybe.", emoji: "🤔" },
      { id: "provavelmente", label: "Probably.", emoji: "👍" },
      { id: "definitivamente", label: "Yes, definitely!", emoji: "🙌" }
    ]
  },
  {
    id: "q_prova_social",
    kind: "question",
    question: "{nome}, are you ready to see results like the women who are already profiting with round popcorn every single month?",
    images: [
      "/assets/proof-1.webp",
      "/assets/proof-2.webp"
    ],
    options: [
      { id: "talvez", label: "Maybe!", emoji: "🤔" },
      { id: "sim", label: "YES!", emoji: "🔥" },
      { id: "certeza", label: "ABSOLUTELY!", emoji: "🚀" }
    ],
    unlocks: {
      id: "b9",
      title: "Access to the gift draw",
      value: 24,
      emoji: "🎟️"
    }
  },
  {
    id: "load_final",
    kind: "loading",
    headline: "Please wait while your results and free gifts are being generated...",
    body: "Watch this quick news report below and see how an ordinary woman turned simple kitchen popcorn into a thriving business.",
    messages: [
      "Analyzing your answers...",
      "Preparing an exclusive training program for you...",
      "Unlocking your gifts..."
    ],
    durationMs: 30000,
    videoUrl: "https://www.youtube.com/watch?v=sQDLtMLsv08"
  },
  {
    id: "result",
    kind: "result",
    headline: "All set, {nome}! This is all yours",
    body: "You unlocked every gift from the gourmet round popcorn method. Tap the button below to get them right now.",
    cta: "Get my gifts",
    ctaHref: "#",
    urgency: "Reservation valid for a limited time"
  }
];
