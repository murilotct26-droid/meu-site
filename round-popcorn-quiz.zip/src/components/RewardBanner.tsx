import React, { useEffect } from 'react';
import { UnlockBonus } from '../quizConfig.ts';
import { playChimeSound } from '../audio.ts';

interface RewardBannerProps {
  bonus: UnlockBonus | null;
  onDone: () => void;
}

export const RewardBanner: React.FC<RewardBannerProps> = ({ bonus, onDone }) => {
  useEffect(() => {
    if (!bonus) return;
    playChimeSound();
    const timer = window.setTimeout(() => onDone(), 2200);
    return () => window.clearTimeout(timer);
  }, [bonus, onDone]);

  if (!bonus) return null;

  return (
    <div className="pointer-events-none fixed inset-x-0 top-0 z-40 border-b border-dashed border-border bg-[#fffdf7] px-5 py-4 shadow-md">
      <div className="animate-pop mx-auto flex w-full max-w-xl items-center justify-center gap-3">
        <span className="text-2xl">{bonus.emoji || '🤑'}</span>
        <div className="leading-tight">
          <p className="text-xs font-bold uppercase tracking-wide text-[#be7a12]">
            You earned
          </p>
          <p className="font-display text-xl tabular-nums text-accent font-bold">
            + ${bonus.value.toLocaleString('en-US')}
          </p>
          <p className="text-[11px] font-semibold text-muted-foreground">
            {bonus.title}
          </p>
        </div>
      </div>
    </div>
  );
};
