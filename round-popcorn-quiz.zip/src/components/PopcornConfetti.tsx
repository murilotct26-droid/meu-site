import React, { useEffect, useMemo, useState } from 'react';

const EMOJIS = ['🍿', '🍿', '🍿', '🌽', '✨', '🍿', '💛', '🍿'];

interface PopcornConfettiProps {
  trigger: number;
}

export const PopcornConfetti: React.FC<PopcornConfettiProps> = ({ trigger }) => {
  const [active, setActive] = useState(false);

  useEffect(() => {
    if (!trigger) return;
    setActive(true);
    const timer = window.setTimeout(() => setActive(false), 1800);
    return () => window.clearTimeout(timer);
  }, [trigger]);

  const particles = useMemo(() => {
    return Array.from({ length: 22 }, (_, idx) => ({
      id: idx,
      emoji: EMOJIS[idx % EMOJIS.length],
      x: (Math.random() - 0.5) * 2,
      rise: 40 + Math.random() * 45,
      delay: Math.random() * 320,
      size: 18 + Math.random() * 22,
      spin: (Math.random() - 0.5) * 720,
    }));
  }, [trigger]);

  if (!active) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-40 overflow-hidden" aria-hidden="true">
      {particles.map((p) => (
        <span
          key={p.id}
          className="popcorn-piece absolute bottom-0 left-1/2"
          style={
            {
              fontSize: `${p.size}px`,
              animationDelay: `${p.delay}ms`,
              '--corn-x': `${p.x * 55}vw`,
              '--corn-rise': `${p.rise}vh`,
              '--corn-spin': `${p.spin}deg`,
            } as React.CSSProperties
          }
        >
          {p.emoji}
        </span>
      ))}
    </div>
  );
};
