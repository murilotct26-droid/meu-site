import React, { useEffect, useRef, useState } from 'react';
import { VideoClipConfig } from '../quizConfig.ts';

interface VideoClipProps {
  clip: VideoClipConfig;
  alt: string;
  className?: string;
}

const INTERACTION_EVENTS = ['touchend', 'click', 'pointerup', 'keydown'];

export const VideoClip: React.FC<VideoClipProps> = ({ clip, alt, className }) => {
  const [mode, setMode] = useState<'poster' | 'video'>('poster');
  const [retryCount, setRetryCount] = useState(0);
  const userInteractedRef = useRef(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const posterSrc = `${clip.src}-poster.webp`;
  const formats = clip.formats ?? ['mp4'];
  const hasFormats = formats.length > 0;

  useEffect(() => {
    if (!hasFormats) return;
    let cancelled = false;
    const triggerVideo = () => {
      if (!cancelled) setMode('video');
    };

    const win = window as unknown as { requestIdleCallback?: (cb: () => void, opts?: { timeout: number }) => number; cancelIdleCallback?: (id: number) => void };
    if (typeof win.requestIdleCallback === 'function') {
      const id = win.requestIdleCallback(triggerVideo, { timeout: 800 });
      return () => {
        cancelled = true;
        win.cancelIdleCallback?.(id);
      };
    }

    const timer = setTimeout(triggerVideo, 150);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [hasFormats]);

  useEffect(() => {
    if (mode !== 'video') return;
    const el = videoRef.current;
    if (!el) return;

    const onPlayFail = () => {
      userInteractedRef.current = true;
      setMode('poster');
    };

    el.play().catch(onPlayFail);

    const onCanPlay = () => {
      if (el.paused) el.play().catch(onPlayFail);
    };

    el.addEventListener('canplay', onCanPlay);
    return () => el.removeEventListener('canplay', onCanPlay);
  }, [mode, retryCount]);

  useEffect(() => {
    if (mode !== 'poster' || !userInteractedRef.current || !hasFormats) return;

    const removeListeners = () => {
      for (const evt of INTERACTION_EVENTS) {
        window.removeEventListener(evt, handleInteraction);
      }
    };

    const handleInteraction = () => {
      removeListeners();
      setRetryCount((c) => c + 1);
      setMode('video');
    };

    for (const evt of INTERACTION_EVENTS) {
      window.addEventListener(evt, handleInteraction, { passive: true });
    }

    return removeListeners;
  }, [mode, retryCount, hasFormats]);

  const commonProps = {
    style: { aspectRatio: `${clip.width} / ${clip.height}` },
    width: clip.width,
    height: clip.height,
    className: `h-auto block ${className ?? ''}`,
  };

  if (mode === 'poster') {
    return <img src={posterSrc} alt={alt} decoding="async" {...commonProps} />;
  }

  return (
    <video
      ref={videoRef}
      autoPlay
      muted
      loop
      playsInline
      preload="auto"
      poster={posterSrc}
      aria-label={alt}
      {...commonProps}
    >
      {formats.includes('webm') && <source src={`${clip.src}.webm`} type="video/webm" />}
      {formats.includes('mp4') && <source src={`${clip.src}.mp4`} type="video/mp4" />}
    </video>
  );
};
