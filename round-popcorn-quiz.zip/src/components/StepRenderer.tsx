import React, { useEffect, useRef, useState } from 'react';
import { QuizStep, HeadlineHighlight } from '../quizConfig.ts';
import { VideoClip } from './VideoClip.tsx';
import { playPopSound, unlockAudio } from '../audio.ts';

interface StepRendererProps {
  step: QuizStep;
  answers: Record<string, string>;
  name: string;
  onAnswer: (stepId: string, optionId: string, goTo?: string) => void;
  onNameChange: (name: string) => void;
  onNext: () => void;
  onLeadSubmit: () => void;
}

function interpolateName(text: string, name: string): string {
  const trimmed = name.trim();
  return text.replace(/\{nome\}/gi, trimmed || 'you');
}

function HighlightedText({
  text,
  highlights,
}: {
  text: string;
  highlights?: HeadlineHighlight[];
}) {
  if (!highlights || highlights.length === 0) {
    return <>{text}</>;
  }

  const nodes: React.ReactNode[] = [];
  let lastIndex = 0;

  for (let i = 0; i < highlights.length; i++) {
    const hl = highlights[i];
    const matchIndex = text.indexOf(hl.text, lastIndex);
    if (matchIndex === -1) continue;

    if (matchIndex > lastIndex) {
      nodes.push(text.slice(lastIndex, matchIndex));
    }

    const className =
      hl.tone === 'gold'
        ? 'whitespace-nowrap font-black text-[#BE7A12] underline decoration-2 decoration-[#BE7A12] underline-offset-4'
        : hl.tone === 'danger'
        ? 'whitespace-nowrap font-black text-destructive underline decoration-2 decoration-destructive underline-offset-4'
        : 'whitespace-nowrap font-black text-accent';

    nodes.push(
      <span key={`${hl.text}-${i}`} className={className}>
        {hl.text}
      </span>
    );

    lastIndex = matchIndex + hl.text.length;
  }

  if (lastIndex < text.length) {
    nodes.push(text.slice(lastIndex));
  }

  return <>{nodes}</>;
}

function StickyCta({ label, onClick }: { label: string; onClick: () => void }) {
  const handleClick = () => {
    unlockAudio();
    playPopSound();
    onClick();
  };

  return (
    <div className="sticky bottom-3 z-40 -mx-5 mt-8 bg-gradient-to-t from-background via-background to-transparent px-5 pb-1 pt-6">
      <button
        type="button"
        className="btn-primary w-full shadow-lg cursor-pointer"
        onClick={handleClick}
      >
        {label}
      </button>
    </div>
  );
}

function ImageSlider({ images }: { images: string[] }) {
  const [index, setIndex] = useState(0);

  const prev = () => {
    playPopSound();
    setIndex((i) => (i - 1 + images.length) % images.length);
  };
  const next = () => {
    playPopSound();
    setIndex((i) => (i + 1) % images.length);
  };

  return (
    <div className="mt-5">
      <div className="relative overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
        <img
          src={images[index]}
          alt={`Testimonial ${index + 1}`}
          loading="lazy"
          className="block w-full object-contain max-h-[460px] mx-auto"
        />
        {images.length > 1 && (
          <>
            <button
              type="button"
              aria-label="Previous"
              onClick={prev}
              className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-background/80 px-3 py-2 text-foreground shadow-soft backdrop-blur hover:bg-background cursor-pointer"
            >
              ‹
            </button>
            <button
              type="button"
              aria-label="Next"
              onClick={next}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-background/80 px-3 py-2 text-foreground shadow-soft backdrop-blur hover:bg-background cursor-pointer"
            >
              ›
            </button>
          </>
        )}
      </div>
      {images.length > 1 && (
        <div className="mt-3 flex justify-center gap-2">
          {images.map((_, i) => (
            <button
              key={i}
              type="button"
              aria-label={`Go to image ${i + 1}`}
              onClick={() => {
                playPopSound();
                setIndex(i);
              }}
              className={`h-2 rounded-full transition-all cursor-pointer ${
                i === index ? 'w-6 bg-accent' : 'w-2 bg-border'
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function LoadingStep({
  step,
  onNext,
}: {
  step: QuizStep;
  onNext: () => void;
}) {
  const [msgIndex, setMsgIndex] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [percent, setPercent] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const continueBtnRef = useRef<HTMLButtonElement | null>(null);

  // Optimized smooth duration: 16 seconds (or instant if user clicks continue)
  const durationMs = 16000;
  const messages = step.messages || [
    'Analyzing your answers...',
    'Preparing an exclusive training program for you...',
    'Unlocking your gifts...',
  ];

  // Base YouTube embed
  const baseVideoId = 'sQDLtMLsv08';
  const iframeSrc = isPlaying
    ? `https://www.youtube.com/embed/${baseVideoId}?autoplay=1&enablejsapi=1&controls=1&modestbranding=1&rel=0`
    : `https://www.youtube.com/embed/${baseVideoId}?enablejsapi=1&controls=1&modestbranding=1&rel=0`;

  const handlePlayVideo = () => {
    unlockAudio();
    setIsPlaying(true);
  };

  // Rotate status messages smoothly
  useEffect(() => {
    const msgInterval = durationMs / messages.length;
    const interval = setInterval(() => {
      setMsgIndex((prev) => Math.min(prev + 1, messages.length - 1));
    }, msgInterval);
    return () => clearInterval(interval);
  }, [durationMs, messages.length]);

  // Smooth, non-conflicting progress bar animation via rAF
  useEffect(() => {
    const start = performance.now();
    let animId = 0;

    const frame = (now: number) => {
      const elapsed = now - start;
      const p = Math.min((elapsed / durationMs) * 100, 100);
      setPercent(p);

      if (p >= 100) {
        setIsCompleted(true);
      } else {
        animId = requestAnimationFrame(frame);
      }
    };

    animId = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(animId);
  }, [durationMs]);

  useEffect(() => {
    if (isCompleted) {
      continueBtnRef.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
  }, [isCompleted]);

  return (
    <section className="relative overflow-hidden rounded-2xl border border-border bg-card p-5 text-center shadow-soft sm:p-8">
      <h2 className="font-display text-lg leading-snug text-foreground sm:text-xl font-bold">
        {step.headline}
      </h2>
      {step.body && (
        <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{step.body}</p>
      )}

      {/* YouTube Video with Reliable Play Overlay */}
      <div className="relative mt-5 aspect-video w-full overflow-hidden rounded-xl border border-border bg-black shadow-soft">
        <iframe
          src={iframeSrc}
          title="News report"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="h-full w-full border-0"
        />
        {!isPlaying && (
          <button
            type="button"
            onClick={handlePlayVideo}
            className="absolute inset-0 flex items-center justify-center bg-black/45 transition hover:bg-black/55 cursor-pointer z-10"
            aria-label="Play news report video"
          >
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-accent text-2xl text-white shadow-xl backdrop-blur-sm transition hover:scale-110">
              ▶
            </span>
          </button>
        )}
      </div>

      {/* Cycling progress message */}
      <p className="mt-5 text-sm font-bold text-accent min-h-[1.5rem]">
        {messages[msgIndex]}
      </p>

      {/* Fixed Smooth Video Progress Bar without CSS transition conflicts */}
      <div className="mx-auto mt-3 h-3 w-full max-w-sm overflow-hidden rounded-full bg-secondary p-0.5 border border-border/40 shadow-inner">
        <div
          className="h-full rounded-full bg-gradient-accent relative overflow-hidden"
          style={{ width: `${percent}%` }}
        >
          <div className="absolute inset-0 bg-white/20 animate-pulse" />
        </div>
      </div>

      <div className="mt-2 flex items-center justify-between text-xs font-mono text-muted-foreground tabular-nums max-w-sm mx-auto px-1">
        <span>Processing answers</span>
        <span className="font-bold text-accent">{Math.round(percent)}%</span>
      </div>

      {/* Continue CTA (only appears when 100% complete) */}
      {isCompleted && (
        <button
          ref={continueBtnRef}
          type="button"
          className="btn-primary mt-6 w-full animate-rise shadow-xl text-base font-bold cursor-pointer"
          onClick={() => {
            playPopSound();
            onNext();
          }}
        >
          Unlock All My Free Gifts Now →
        </button>
      )}
    </section>
  );
}

export const StepRenderer: React.FC<StepRendererProps> = ({
  step,
  answers,
  name,
  onAnswer,
  onNameChange,
  onNext,
  onLeadSubmit,
}) => {
  const [carouselPaused, setCarouselPaused] = useState(false);
  const p = (text?: string) => (text ? interpolateName(text, name) : '');

  // 1. INTRO STEP
  if (step.kind === 'intro') {
    return (
      <section className="pb-16 text-center md:text-left">
        {step.greeting && (
          <p className="text-xs font-semibold uppercase tracking-wider text-accent">
            {step.greeting}
          </p>
        )}
        <h1 className="font-display text-xl leading-snug text-foreground md:text-2xl font-bold">
          <HighlightedText text={step.headline || ''} highlights={step.headlineHighlights} />
        </h1>

        {step.clip && (
          <VideoClip
            clip={step.clip}
            alt="Woman making gourmet popcorn at home"
            className="pointer-events-none mt-4 w-[110%] -mx-[5%] max-w-none bg-transparent rounded-xl"
          />
        )}

        <p className="mt-4 text-lg font-medium text-foreground sm:text-xl">
          <HighlightedText text={step.subline || ''} highlights={step.sublineHighlights} />
        </p>

        <StickyCta label={`${step.cta} →`} onClick={onNext} />

        <p className="mt-3 text-xs text-muted-foreground text-center md:text-left">
          ⏱️ {step.footnote}
        </p>
      </section>
    );
  }

  // 2. FORM STEP
  if (step.kind === 'form') {
    const isNameValid = name.trim().length >= 1;

    return (
      <section className="rounded-2xl border border-border bg-card p-6 shadow-soft sm:p-7">
        <h2 className="font-display text-xl leading-snug text-foreground font-bold">
          {p(step.headline)}
        </h2>
        {step.body && (
          <p className="mt-2 text-sm text-muted-foreground">{p(step.body)}</p>
        )}

        <form
          className="mt-6 space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (isNameValid) {
              unlockAudio();
              playPopSound();
              onLeadSubmit();
            }
          }}
        >
          {step.fields?.map((field) => (
            <label key={field.id} className="block">
              <span className="text-sm font-medium text-foreground">{field.label}</span>
              <input
                type={field.type}
                name={field.id}
                autoFocus
                autoComplete={field.autoComplete ?? 'on'}
                autoCapitalize={field.type === 'text' ? 'words' : 'off'}
                enterKeyHint="go"
                placeholder={field.placeholder}
                value={name}
                onChange={(e) => onNameChange(e.target.value)}
                className="mt-1.5 w-full rounded-xl border border-input bg-background px-4 py-3 text-base text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/40"
              />
            </label>
          ))}

          <button
            type="submit"
            className="btn-primary w-full shadow-lg cursor-pointer"
            disabled={!isNameValid}
          >
            {step.cta}
          </button>

          {!isNameValid && (
            <p className="text-center text-xs text-muted-foreground">
              Type your name above to unlock your first gift
            </p>
          )}

          {step.disclaimer && (
            <p className="text-center text-xs text-muted-foreground">{step.disclaimer}</p>
          )}
        </form>
      </section>
    );
  }

  // 3. QUESTION STEP
  if (step.kind === 'question') {
    const handleOptionSelect = (optionId: string, goTo?: string) => {
      unlockAudio();
      playPopSound();
      onAnswer(step.id, optionId, goTo);
    };

    return (
      <section>
        {step.unlocks && (
          <span className="inline-flex items-center gap-1.5 rounded-full border border-green-600/30 bg-green-50 px-3 py-1 text-xs font-bold text-green-700 mb-2">
            <span className="corn-float inline-block">🍿</span>
            Answer and pop +${step.unlocks.value.toLocaleString('en-US')}
          </span>
        )}

        {step.eyebrow && (
          <p className="mt-2 text-xs font-semibold uppercase tracking-widest text-accent">
            {step.eyebrow}
          </p>
        )}

        <h2 className="mt-2 font-display text-xl leading-snug text-foreground font-bold">
          {p(step.question)}
        </h2>

        {step.helper && (
          <p className="mt-2 text-sm text-muted-foreground">{p(step.helper)}</p>
        )}

        <div className="mt-6 space-y-3">
          {step.options?.map((opt) => (
            <button
              key={opt.id}
              type="button"
              className={`option-card ${
                answers[step.id] === opt.id ? 'option-card-active' : ''
              }`}
              onClick={() => handleOptionSelect(opt.id, opt.goTo)}
            >
              <span aria-hidden="true" className="text-xl">
                {opt.emoji ?? '•'}
              </span>
              <span className="flex-1 text-left font-medium text-foreground">
                {opt.label}
              </span>
              <span aria-hidden="true" className="text-muted-foreground font-bold">
                →
              </span>
            </button>
          ))}
        </div>

        {step.images && step.images.length > 0 && <ImageSlider images={step.images} />}
      </section>
    );
  }

  // 4. RETENTION STEP
  if (step.kind === 'retention') {
    return (
      <section className="rounded-2xl border border-border bg-card p-7 text-center shadow-soft">
        {step.eyebrow && (
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">
            {step.eyebrow}
          </p>
        )}
        <h2 className="mt-2 font-display text-xl leading-snug text-foreground font-bold">
          {p(step.headline)}
        </h2>
        <p className="mt-3 text-base leading-relaxed text-muted-foreground">
          {p(step.body)}
        </p>

        {step.clip ? (
          <VideoClip
            clip={step.clip}
            alt="Local craft fair"
            className="pointer-events-none mt-5 w-full rounded-xl shadow-soft"
          />
        ) : step.image ? (
          <img
            src={step.image}
            alt="Local craft fair"
            className="mt-5 w-full rounded-xl object-cover shadow-soft"
          />
        ) : null}

        <StickyCta label={step.cta || 'Continue'} onClick={onNext} />
      </section>
    );
  }

  // 5. CONTENT STEP
  if (step.kind === 'content') {
    return (
      <section className="rounded-2xl border border-border bg-card p-6 shadow-soft sm:p-7">
        {step.eyebrow && (
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">
            {step.eyebrow}
          </p>
        )}
        <h2 className="mt-2 font-display text-xl leading-snug text-foreground font-bold">
          {p(step.headline)}
        </h2>

        {/* Calculation breakdown */}
        {step.calculation && (
          <div className="mt-6 space-y-3">
            {step.calculation.map((row, idx) => (
              <div key={row.label}>
                {row.highlight ? (
                  <div className="rounded-2xl border border-accent/40 bg-gradient-to-br from-accent/20 to-accent/5 p-5 text-center shadow-soft">
                    <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-600 text-2xl text-white shadow-md">
                      {row.emoji ?? '•'}
                    </span>
                    <p className="mt-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      {row.label}
                    </p>
                    <p className="mt-1 whitespace-nowrap font-display text-2xl tabular-nums leading-tight text-accent font-bold">
                      {row.value}
                    </p>
                  </div>
                ) : (
                  <div className="flex items-center gap-4 rounded-2xl border border-border bg-background p-4 shadow-soft transition">
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-secondary text-2xl">
                      {row.emoji ?? '•'}
                    </span>
                    <div className="min-w-0 flex-1 text-left">
                      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        {row.label}
                      </p>
                      <p className="mt-0.5 font-display text-lg tabular-nums leading-tight text-foreground font-bold">
                        {row.value}
                      </p>
                    </div>
                  </div>
                )}
                {idx < (step.calculation?.length || 0) - 1 && (
                  <div className="flex justify-center py-1">
                    <div className="h-5 w-px bg-gradient-to-b from-border to-accent/50" />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Advantage comparison blocks */}
        {step.blocks && (
          <div className="mt-6 space-y-4">
            <div className="relative overflow-hidden rounded-2xl border border-accent/30 bg-card bg-gradient-to-br from-accent/20 via-accent/10 to-background p-5 text-center shadow-soft">
              <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-accent/10 blur-2xl" />
              <p className="relative text-xs font-semibold uppercase tracking-wider text-accent font-bold">
                Unfair advantage
              </p>
              <h3 className="relative mt-2 font-display text-lg text-foreground font-bold">
                Gourmet Round Popcorn
              </h3>
              <div className="relative mt-4 flex flex-wrap items-center justify-center gap-2">
                <span className="rounded-full bg-background px-3 py-1 text-xs font-medium text-muted-foreground shadow-sm">
                  cookies
                </span>
                <span className="text-xs font-bold text-accent">VS</span>
                <span className="rounded-full bg-background px-3 py-1 text-xs font-medium text-muted-foreground shadow-sm">
                  cupcakes
                </span>
                <span className="text-xs font-bold text-accent">VS</span>
                <span className="rounded-full bg-accent bg-gradient-to-r from-accent to-accent/80 px-3 py-1 text-xs font-bold text-white shadow-sm">
                  round popcorn
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {step.blocks.map((b, idx) => {
                const isFull = idx === 0 || idx === 5;
                return (
                  <div
                    key={b.title}
                    className={`group relative overflow-hidden rounded-2xl border border-border bg-background p-4 shadow-soft transition-all duration-200 hover:-translate-y-0.5 hover:border-accent/40 hover:shadow-md ${
                      isFull ? 'col-span-2' : ''
                    }`}
                  >
                    <div className={`flex ${isFull ? 'items-center gap-4' : 'flex-col gap-2'}`}>
                      <span
                        className={`flex shrink-0 items-center justify-center rounded-xl bg-accent/10 text-2xl text-accent ${
                          isFull ? 'h-12 w-12' : 'h-10 w-10'
                        }`}
                      >
                        {b.emoji ?? '•'}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-foreground text-sm sm:text-base">
                          {b.title}
                        </p>
                        <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                          {p(b.text)}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Bullets */}
        {step.bullets && (
          <ul className="mt-5 space-y-2.5">
            {step.bullets.map((b) => (
              <li key={b} className="flex gap-2.5 text-sm text-foreground">
                <span aria-hidden="true" className="text-green-600 font-bold">
                  ✔
                </span>
                <span>{p(b)}</span>
              </li>
            ))}
          </ul>
        )}

        {step.body && (
          <p className="mt-5 text-sm text-muted-foreground leading-relaxed">{p(step.body)}</p>
        )}

        {/* Bestsellers Gallery */}
        {step.gallery && (
          <div className="mt-8">
            <p className="text-center text-xs font-semibold uppercase tracking-[0.3em] text-accent font-bold">
              ★ {step.galleryTitle ?? 'Bestsellers'} ★
            </p>
            <div className="mt-4 grid grid-cols-2 gap-3">
              {step.gallery.map((item) => (
                <div
                  key={item.title}
                  className="overflow-hidden rounded-2xl border border-border bg-background shadow-soft transition-transform duration-200 hover:-translate-y-0.5"
                >
                  <img
                    src={item.image}
                    alt={item.title}
                    loading="lazy"
                    className="aspect-square w-full object-cover"
                  />
                  <div className="p-3 text-center">
                    <p className="font-display text-sm leading-tight text-foreground font-bold">
                      {item.title}
                    </p>
                    <p className="mt-1 text-[11px] leading-snug text-muted-foreground">
                      {item.text}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <StickyCta label={step.cta || 'Continue'} onClick={onNext} />
      </section>
    );
  }

  // 6. TIMELINE STEP
  if (step.kind === 'timeline' && step.items) {
    const duplicated = [...step.items, ...step.items];
    return (
      <section>
        {step.eyebrow && (
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">
            {step.eyebrow}
          </p>
        )}
        <h2 className="mt-2 font-display text-xl leading-snug text-foreground font-bold">
          {p(step.headline)}
        </h2>
        {step.body && (
          <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{p(step.body)}</p>
        )}

        <div className="relative -mx-5 mt-8 overflow-x-auto overscroll-x-contain [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <div
            className="carousel-track gap-4 px-5"
            onClick={() => setCarouselPaused((v) => !v)}
            style={{
              animationDuration: '70s',
              animationPlayState: carouselPaused ? 'paused' : undefined,
            }}
          >
            {duplicated.map((item, idx) => (
              <div
                key={`${item.phase}-${idx}`}
                className="w-[16.5rem] shrink-0 overflow-hidden rounded-2xl border border-border bg-card shadow-soft"
              >
                {item.image ? (
                  <img
                    src={item.image}
                    alt={item.title}
                    loading="lazy"
                    draggable={false}
                    className="aspect-square w-full object-cover"
                  />
                ) : (
                  <div className="flex aspect-[4/3] items-center justify-center bg-secondary bg-gradient-to-br from-[#f3e6d8] to-[#e9d5c0]">
                    <span className="text-5xl" aria-hidden="true">
                      {item.emoji ?? '✨'}
                    </span>
                  </div>
                )}
                <div className="p-4 text-center">
                  <span className="rounded-full bg-accent/10 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent">
                    {item.phase}
                  </span>
                  <p className="mt-2 text-xs font-bold text-muted-foreground uppercase tracking-wider">
                    {item.subtitle}
                  </p>
                  <h3 className="mt-0.5 font-display text-base font-bold text-foreground">
                    {item.title}
                  </h3>
                  <p className="mt-1.5 text-xs text-muted-foreground leading-relaxed">
                    {item.text}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <StickyCta label={step.cta || 'Got it, continue'} onClick={onNext} />
      </section>
    );
  }

  // 7. LOADING STEP
  if (step.kind === 'loading') {
    return <LoadingStep step={step} onNext={onNext} />;
  }

  return null;
};
