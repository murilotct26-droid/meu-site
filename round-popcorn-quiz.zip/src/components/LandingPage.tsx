import React, { useEffect, useMemo, useRef, useState } from 'react';

interface GiftItem {
  title: string;
  desc: string;
  value: number;
  img: string;
}

const RESERVED_GIFTS: GiftItem[] = [
  {
    title: 'Instagram That Sells',
    desc: 'Get paying customers for free, starting this week.',
    value: 47,
    img: '/assets/bullets1.webp',
  },
  {
    title: '"Your Brand" Label Kit',
    desc: 'Print-ready premium labels and packaging templates.',
    value: 19,
    img: '/assets/bullets2.webp',
  },
  {
    title: 'Fair Price Calculator',
    desc: 'Price every batch for profit. No math required.',
    value: 15,
    img: '/assets/bullets3.webp',
  },
  {
    title: 'Boss Lady Business Planner',
    desc: 'Plan your week, orders and income goals.',
    value: 37,
    img: '/assets/bullets4.webp',
  },
];

const FLAVORS = [
  { name: 'Oreo', desc: 'A worldwide classic that everyone loves', image: '/assets/oreo.webp' },
  { name: 'Kinder Bueno', desc: 'An exclusive flavor with a sophisticated twist', image: '/assets/kinderbueno.webp' },
  { name: 'Nutella', desc: "Everyone's favorite hazelnut cream", image: '/assets/nutella.webp' },
  { name: 'Pink Lemonade', desc: 'Refreshing, citrusy, and irresistible', image: '/assets/pink-lemonade.webp' },
  { name: 'Milk Cream', desc: 'Smooth, creamy, and nostalgic', image: '/assets/milk-cream.webp' },
  { name: 'Salted Caramel', desc: 'The perfect balance of sweet and salty', image: '/assets/salted-caramel.webp' },
];

const TESTIMONIALS = [
  '/assets/testimonial-2.webp',
  '/assets/testimonial-3.webp',
  '/assets/testimonial-4.webp',
  '/assets/testimonial-5.webp',
  '/assets/testimonial-6.webp',
];

const FAQS = [
  {
    q: 'Do I need any special equipment to get started?',
    a: "No! You can start with what you already have at home. A regular pot and a few basic ingredients are enough to make your first gourmet round popcorn. As your business grows, you can invest in more professional equipment, but it's not required at the beginning.",
  },
  {
    q: 'Can I find the ingredients in my country?',
    a: "Yes! The ingredients used are very common and you'll find them in most supermarkets around the world. If any specific item isn't available in your area, you can simply order it online — these days, almost anything can be delivered straight to your door with just a few clicks.",
  },
  {
    q: 'Do I need any cooking experience?',
    a: 'Not at all. We teach everything from scratch. All you need is motivation and to follow the step-by-step instructions.',
  },
  {
    q: 'How much can I earn selling gourmet popcorn?',
    a: 'It depends on your dedication, but many students report between 20 and 200 orders per month, with margins of 60–80%.',
  },
  {
    q: 'How long until my business is up and running?',
    a: 'In 7 to 14 days you can have your first recipes ready and start selling.',
  },
  {
    q: 'Is access lifetime?',
    a: 'Yes. You pay once and get access to the course, all future updates, and all 8 bonuses forever.',
  },
  {
    q: 'Is there a guarantee?',
    a: "Yes. 7-day unconditional money-back guarantee. If you don't love it, we refund 100%.",
  },
  {
    q: 'How do I access the course?',
    a: "Immediately after payment, you'll receive an email with access to the online platform.",
  },
];

const CONFETTI_COLORS = ['#C9A961', '#F0C766', '#7A4A08', '#FDFCFA', '#2aa549', '#922847'];

function LandingConfetti() {
  const [show, setShow] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setShow(false), 2600);
    return () => clearTimeout(t);
  }, []);

  if (!show) return null;

  const pieces = Array.from({ length: 80 });

  return (
    <div className="fixed inset-0 z-[120] pointer-events-none overflow-hidden" aria-hidden="true">
      {pieces.map((_, i) => {
        const dx = (Math.random() * 2 - 1) * 380;
        const dy = (Math.random() * 2 - 1) * 320;
        const rot = (Math.random() * 720 + 200) * (Math.random() < 0.5 ? -1 : 1);
        const size = 6 + Math.random() * 9;
        const w = size;
        const h = Math.random() < 0.5 ? size : size * 0.45;
        const color = CONFETTI_COLORS[i % CONFETTI_COLORS.length];

        return (
          <span
            key={i}
            className="absolute rounded-[1px] animate-[confetti-burst_1800ms_ease-out_forwards]"
            style={
              {
                left: '50%',
                top: '40%',
                width: `${w}px`,
                height: `${h}px`,
                backgroundColor: color,
                '--dx': `${dx}px`,
                '--dy': `${dy}px`,
                '--rot': `${rot}deg`,
                animationDelay: `${Math.random() * 150}ms`,
              } as React.CSSProperties
            }
          />
        );
      })}
    </div>
  );
}

const KIWIFY_CHECKOUT_URL = 'https://pay.kiwify.com/cX2gD2C';

function getCheckoutUrl(): string {
  if (typeof window === 'undefined') return KIWIFY_CHECKOUT_URL;
  try {
    const search = window.location.search;
    if (!search) return KIWIFY_CHECKOUT_URL;
    const url = new URL(KIWIFY_CHECKOUT_URL);
    const currentParams = new URLSearchParams(search);
    currentParams.forEach((val, key) => {
      url.searchParams.set(key, val);
    });
    return url.toString();
  } catch {
    return KIWIFY_CHECKOUT_URL;
  }
}

function handleCheckoutClick() {
  if (typeof window !== 'undefined' && typeof (window as unknown as { fbq?: (...args: unknown[]) => void }).fbq === 'function') {
    try {
      (window as unknown as { fbq: (...args: unknown[]) => void }).fbq('track', 'InitiateCheckout');
    } catch {
      // Ignored
    }
  }
}

function useOfferDates(): string {
  const [dates, setDates] = useState('');

  useEffect(() => {
    const now = new Date();
    const past = new Date(now);
    past.setDate(now.getDate() - 2);

    const fmt = (d: Date) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    setDates(`${fmt(past)} – ${fmt(now)}`);
  }, []);

  return dates;
}

export function LandingPage({
  name,
  quizTotal,
  quizGifts,
}: {
  name: string;
  quizTotal: number;
  quizGifts: Array<{ title: string; value: number }>;
}) {
  const displayName = name.trim() || 'there';
  const offerDates = useOfferDates();
  const [showStickyCta, setShowStickyCta] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const testimonialScrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setShowStickyCta(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToOffer = () => {
    const el = document.getElementById('offer-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#f6f1e4] pb-24 text-foreground selection:bg-marsala selection:text-white md:pb-0">
      <LandingConfetti />

      {/* TOP HERO */}
      <section className="bg-warm-cream px-4 pb-12 pt-9">
        <div className="mx-auto max-w-4xl">
          <div className="text-center">
            <p className="text-[0.68rem] font-black uppercase tracking-[0.22em] text-marsala/70">
              Quiz complete
            </p>
            <h1 className="mx-auto mt-3 max-w-2xl text-balance text-[1.6rem] font-black leading-[1.15] tracking-tight text-marsala sm:text-[2.4rem]">
              Congratulations, {displayName}! You qualified for Carmela Vega’s{' '}
              <span className="gold-accent">Gourmet Round Popcorn</span>
            </h1>

            {quizTotal > 0 && (
              <div className="mx-auto mt-5 max-w-lg rounded-2xl border border-success/30 bg-green-50 px-4 py-4 shadow-sm">
                <p className="text-[0.68rem] font-black uppercase tracking-[0.2em] text-marsala">
                  {displayName}, you unlocked
                </p>
                <p className="mt-1 font-black leading-none text-green-700 text-[2.2rem]">
                  ${quizTotal.toLocaleString('en-US')}
                </p>
                <p className="mt-1 text-[0.68rem] font-black uppercase tracking-[0.2em] text-marsala/70">
                  in gifts · reserved in your name
                </p>
                {quizGifts.length > 0 && (
                  <p className="mt-3 text-xs font-semibold leading-relaxed text-foreground/70">
                    {quizGifts.map((g) => g.title).join(' · ')}
                  </p>
                )}
              </div>
            )}

            <p className="mx-auto mt-4 max-w-lg text-sm font-semibold leading-relaxed text-foreground/75 sm:text-base">
              Your 4 free gifts are reserved below, they unlock instantly with your access.
            </p>
          </div>

          {/* 4 RESERVED GIFTS */}
          <div className="mt-8 rounded-3xl border border-marsala/10 bg-ivory/80 p-3 sm:p-5 shadow-sm">
            <div className="mb-3 flex items-center justify-between px-1">
              <p className="text-[0.7rem] font-black uppercase tracking-[0.18em] text-marsala">
                Your reserved gifts
              </p>
              <p className="text-[0.7rem] font-black uppercase tracking-[0.18em] text-green-700">
                $118 value · free
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {RESERVED_GIFTS.map((g) => (
                <article
                  key={g.title}
                  className="flex items-center gap-3 rounded-2xl border border-marsala/10 bg-card p-3 shadow-xs transition-shadow hover:shadow-md"
                >
                  <img
                    src={g.img}
                    alt={`${g.title} e-book mockup`}
                    width={160}
                    height={200}
                    className="h-[4.5rem] w-[3.5rem] shrink-0 rounded-lg object-cover shadow-[4px_5px_12px_-6px_rgba(0,0,0,0.45)]"
                    loading="lazy"
                  />
                  <div className="min-w-0">
                    <h3 className="text-[0.92rem] font-black leading-tight text-foreground">
                      {g.title}
                    </h3>
                    <p className="mt-1 text-xs font-medium leading-snug text-muted-foreground">
                      {g.desc}
                    </p>
                    <p className="mt-1.5 flex items-center gap-1.5 text-[0.68rem] font-black uppercase tracking-wider">
                      <span className="text-muted-foreground/70 line-through">${g.value}</span>
                      <span className="rounded-full bg-green-100 px-2 py-0.5 text-green-700">
                        Free
                      </span>
                    </p>
                  </div>
                </article>
              ))}
            </div>
          </div>

          {/* CTA TO OFFER */}
          <div className="mt-8 text-center">
            <button
              type="button"
              onClick={scrollToOffer}
              className="btn-primary w-full sm:w-auto sm:px-12 text-base font-bold shadow-lg cursor-pointer"
            >
              Claim My Access & Gifts Now →
            </button>
            <p className="mt-3 text-[0.68rem] font-black uppercase tracking-[0.18em] text-muted-foreground">
              Instant access • 7-day guarantee
            </p>
          </div>
        </div>
      </section>

      {/* TRAINING CONTENTS */}
      <section className="bg-background px-4 pb-14 pt-6">
        <div className="mx-auto max-w-3xl">
          <h2 className="text-center text-[1.5rem] font-black leading-tight tracking-tight text-marsala sm:text-4xl">
            Here is what you unlock inside
          </h2>
          <p className="mt-2 text-center text-sm font-semibold text-muted-foreground">
            The complete training, all in one place.
          </p>
          <ul className="mt-7 divide-y divide-marsala/10 overflow-hidden rounded-2xl border border-marsala/10 bg-soft-pink shadow-xs">
            {[
              '65+ bestselling gourmet popcorn recipes, step by step.',
              'The crunch technique that keeps popcorn fresh for 20 days.',
              'Luxury packaging that lets you charge premium prices.',
              'Ready-to-post captions to sell every single day.',
              'The Party Playbook for big-ticket event orders.',
              'Your first customers in 7 days, straight from your kitchen.',
            ].map((text) => (
              <li key={text} className="flex items-start gap-3 px-4 py-4">
                <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-green-600 text-white text-xs font-bold">
                  ✓
                </span>
                <span className="text-sm font-bold leading-snug text-foreground/85 sm:text-base">
                  {text}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* 60+ FLAVORS SECTION */}
      <section className="py-16 md:py-24 px-4 bg-warm-cream">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-block bg-marsala text-white font-black py-2 px-8 rounded-full text-xs uppercase tracking-widest shadow-md mb-6">
            ★ OVER 60 BESTSELLING RECIPES ★
          </div>
          <h2 className="text-3xl md:text-5xl font-black text-foreground mb-4 leading-tight">
            Inside, you will master over <span className="gold-accent">60+ Premium Flavors</span>
          </h2>
          <p className="text-muted-foreground font-semibold text-base md:text-lg mb-12 max-w-2xl mx-auto">
            From timeless classics to high-ticket gourmet sensations that sell at 4x the price.
          </p>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
            {FLAVORS.map((f) => (
              <div
                key={f.name}
                className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-transform hover:-translate-y-1"
              >
                <img
                  src={f.image}
                  alt={f.name}
                  loading="lazy"
                  className="aspect-square w-full object-cover"
                />
                <div className="p-4 text-center">
                  <h4 className="font-display font-bold text-base md:text-lg text-foreground">
                    {f.name}
                  </h4>
                  <p className="mt-1 text-xs text-muted-foreground">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING & OFFER BOX */}
      <section id="offer-section" className="scroll-mt-10 bg-background px-4 py-14">
        <div className="mx-auto max-w-md overflow-hidden rounded-3xl border border-marsala/20 bg-ivory shadow-xl">
          <div className="bg-marsala px-5 py-3 text-center">
            <p className="text-[0.7rem] font-black uppercase tracking-[0.18em] text-white">
              {displayName}, your quiz reward is active
            </p>
          </div>

          <div className="px-6 py-8 text-center sm:px-9">
            <p className="text-[0.7rem] font-black uppercase tracking-[0.18em] text-marsala">
              Everything you get today
            </p>

            <ul className="mx-auto mt-4 space-y-2.5 text-left">
              {[
                ['Complete Gourmet Popcorn System', '$197'],
                ['Instagram That Sells (gift)', '$47'],
                ['"Your Brand" Label Kit (gift)', '$19'],
                ['Fair Price Calculator (gift)', '$15'],
                ['Boss Lady Business Planner (gift)', '$37'],
              ].map(([title, val]) => (
                <li
                  key={title}
                  className="flex items-start justify-between gap-3 border-b border-marsala/10 pb-2.5 last:border-0"
                >
                  <span className="flex items-start gap-2 text-[0.82rem] font-bold leading-snug text-foreground/85">
                    <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-green-600 text-white text-[10px] font-bold">
                      ✓
                    </span>
                    {title}
                  </span>
                  <span className="shrink-0 text-[0.82rem] font-black text-muted-foreground/70 line-through">
                    {val}
                  </span>
                </li>
              ))}
            </ul>

            <p className="mt-4 text-[0.78rem] font-black uppercase tracking-[0.14em] text-marsala">
              Total real value: $315
            </p>

            <p className="mt-6 inline-flex items-center gap-2 rounded-full bg-green-100 px-4 py-1.5 text-[0.7rem] font-black uppercase tracking-[0.14em] text-green-800">
              ⏳ Promo valid {offerDates} · ends tonight
            </p>

            <p className="mt-4 text-sm font-semibold text-muted-foreground">
              Regular price <span className="line-through">$67</span>
            </p>

            <p className="mt-1 text-6xl font-black leading-none tracking-tighter text-green-700">
              $14.87
            </p>

            <p className="mt-3 text-xs font-semibold text-muted-foreground">
              One-time payment · Lifetime access · No recurring fees
            </p>

            <div className="mt-7">
              <a
                href={getCheckoutUrl()}
                onClick={handleCheckoutClick}
                className="w-full rounded-full bg-green-600 hover:bg-green-700 px-6 py-4 text-base sm:text-lg font-black uppercase tracking-tight text-white shadow-xl transition hover:scale-105 cta-breathe inline-flex items-center justify-center text-center no-underline cursor-pointer"
              >
                CLAIM MY ACCESS & FREE GIFTS NOW ➔
              </a>
            </div>

            <p className="mt-4 flex items-center justify-center gap-1.5 text-[0.68rem] font-black uppercase tracking-[0.18em] text-muted-foreground">
              <span>🔒</span> 100% secure payment
            </p>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-16 md:py-24 px-4 bg-warm-cream overflow-hidden">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-black text-foreground mb-4 leading-tight">
            People who started are already <span className="gold-accent">earning income</span> with popcorn
          </h2>
          <p className="text-muted-foreground font-black mb-12 uppercase tracking-widest text-xs italic">
            Real proof from our students who transformed their lives
          </p>

          <div className="relative group">
            <button
              type="button"
              onClick={() => testimonialScrollRef.current?.scrollBy({ left: -360, behavior: 'smooth' })}
              aria-label="Previous"
              className="absolute left-2 top-1/2 -translate-y-1/2 z-20 bg-card/90 hover:bg-marsala hover:text-white p-3 rounded-full shadow-xl transition-all hidden sm:flex items-center justify-center cursor-pointer"
            >
              ‹
            </button>
            <button
              type="button"
              onClick={() => testimonialScrollRef.current?.scrollBy({ left: 360, behavior: 'smooth' })}
              aria-label="Next"
              className="absolute right-2 top-1/2 -translate-y-1/2 z-20 bg-card/90 hover:bg-marsala hover:text-white p-3 rounded-full shadow-xl transition-all hidden sm:flex items-center justify-center cursor-pointer"
            >
              ›
            </button>

            <div
              ref={testimonialScrollRef}
              className="flex gap-4 sm:gap-6 overflow-x-auto snap-x snap-mandatory no-scrollbar pb-6 px-4"
            >
              {TESTIMONIALS.map((tSrc, idx) => (
                <article
                  key={tSrc}
                  className="snap-center shrink-0 w-[85%] sm:w-[380px] bg-card rounded-2xl overflow-hidden shadow-lg border border-border"
                >
                  <img
                    src={tSrc}
                    alt={`Student testimonial ${idx + 1}`}
                    loading="lazy"
                    className="w-full object-cover"
                  />
                  <div className="p-4 text-center bg-card">
                    <p className="text-xs font-bold text-green-700">Verified Student Result ★★★★★</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* MEET INSTRUCTOR */}
      <section className="pt-16 pb-24 px-4 bg-[linear-gradient(165deg,#7B1533_0%,#610B24_100%)] text-white">
        <div className="max-w-5xl mx-auto flex flex-col items-center text-center">
          <h2 className="text-4xl md:text-6xl font-black text-[#fffdf5] mb-8 leading-tight">
            Meet Your <span className="gold-accent gold-accent-shadow">Instructor</span>
          </h2>

          <div className="mb-8 aspect-square max-w-sm w-full rounded-[1.5rem] bg-[linear-gradient(135deg,#F0C766_0%,#BE7A12_50%,#7A4A08_100%)] p-2 shadow-2xl">
            <img
              src="/assets/EXPERT.webp"
              alt="Carmela Vega - Gourmet Popcorn Expert & Instructor"
              width={1094}
              height={1094}
              className="w-full h-full rounded-[1.1rem] object-cover"
              loading="lazy"
            />
          </div>

          <p className="text-3xl md:text-5xl font-black text-[#fffdf5] mb-8 leading-relaxed uppercase tracking-widest">
            Carmela Vega
          </p>

          <div className="max-w-3xl mx-auto text-left mb-12 space-y-5 text-white/90 text-lg md:text-xl font-medium leading-relaxed">
            <p>
              More than a gourmet popcorn expert, I'm the creator of the 20-Day Crunch Method and over 65 flavors that are now trending in the market.
            </p>
            <p>
              My mission is clear: teach real people how to turn their kitchen into a source of income, no boss, no schedule, even starting with zero experience.
            </p>
            <p>
              My students are already living this. From those closing massive catering contracts for weddings and events (earning a month's salary in a single day), to those selling daily through Instagram and Etsy from home. They turned kernels into gold, and you're next.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-3 md:gap-6 w-full max-w-3xl">
            {[
              { label: 'students', value: '+1,564' },
              { label: 'flavors', value: '+65' },
              { label: 'events', value: '+387' },
            ].map((stat) => (
              <div
                key={stat.label}
                className="bg-card p-5 md:p-8 rounded-2xl text-center shadow-xl border border-pink-100 flex flex-col items-center justify-center text-foreground"
              >
                <div className="text-marsala font-black text-2xl md:text-4xl mb-1">{stat.value}</div>
                <div className="text-xs uppercase font-bold tracking-wider text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* GUARANTEE */}
      <section className="py-14 px-4 bg-background">
        <div className="max-w-4xl mx-auto bg-card rounded-[1.75rem] p-8 md:p-14 border border-pink-100 flex flex-col md:flex-row items-center gap-8 md:gap-14 shadow-lg">
          <div className="shrink-0 flex flex-col items-center">
            <img
              src="/assets/7days.webp"
              alt="7 Day Money Back Guarantee"
              width={350}
              height={350}
              className="w-36 md:w-48 h-auto drop-shadow-md"
              loading="lazy"
            />
          </div>
          <div className="text-center md:text-left">
            <h3 className="text-2xl md:text-4xl font-black text-foreground mb-4 leading-tight">
              Your Risk Is <span className="gold-accent">ZERO</span>!
            </h3>
            <p className="text-muted-foreground text-base md:text-lg font-medium leading-relaxed">
              Enroll today and try the entire method. If within the first 7 days you feel this business isn't for you, just send us a message and we'll refund 100% of your investment. No questions asked, no hassle, no hard feelings. My commitment is to your success.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-24 px-4 bg-warm-cream">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-5xl font-black text-center text-marsala mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-center text-sm font-semibold text-muted-foreground mb-12">
            We answer all your questions
          </p>

          <div className="space-y-4">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={faq.q}
                  className="bg-card rounded-2xl border border-border shadow-xs overflow-hidden transition"
                >
                  <button
                    type="button"
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full text-left p-6 sm:p-7 flex items-center justify-between gap-4 cursor-pointer"
                  >
                    <h3 className="font-bold text-foreground text-base sm:text-lg">{faq.q}</h3>
                    <span className="text-xl font-bold text-marsala">{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && (
                    <div className="px-6 sm:px-7 pb-6 pt-0 text-muted-foreground text-sm sm:text-base leading-relaxed">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="text-center mt-12">
            <a
              href={getCheckoutUrl()}
              onClick={handleCheckoutClick}
              className="btn-primary px-10 py-4 text-base sm:text-lg font-bold shadow-xl inline-flex items-center justify-center text-center no-underline cursor-pointer"
            >
              CLAIM MY ACCESS & FREE GIFTS NOW ➔
            </a>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-10 text-center text-muted-foreground text-sm bg-background border-t border-border">
        <p className="font-black uppercase tracking-widest text-xs">
          © {new Date().getFullYear()} Living Off Gourmet Popcorn
        </p>
        <p className="mt-2 text-xs opacity-75">
          This product is sold with the support of Hotmart.
        </p>
        <div className="mt-4 flex items-center justify-center gap-4 text-xs opacity-60">
          <span>Privacy Policy</span>
          <span>|</span>
          <span>Cookie Policy</span>
          <span>|</span>
          <span>Terms of Service</span>
        </div>
      </footer>

      {/* STICKY MOBILE CTA */}
      <div
        className={`fixed inset-x-0 bottom-0 z-[60] border-t border-black/10 bg-ivory/95 p-3 backdrop-blur transition-transform duration-300 md:hidden ${
          showStickyCta ? 'translate-y-0' : 'translate-y-full'
        }`}
      >
        <a
          href={getCheckoutUrl()}
          onClick={handleCheckoutClick}
          className="w-full rounded-full bg-green-600 px-4 py-4 text-sm font-black uppercase tracking-tight text-white shadow-lg inline-flex items-center justify-center text-center no-underline cursor-pointer"
        >
          CLAIM MY ACCESS & FREE GIFTS NOW ➔
        </a>
      </div>
    </div>
  );
}
