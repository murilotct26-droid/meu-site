import React, { useEffect, useRef, useState } from 'react';
import { getLevelForScore } from '../quizConfig.ts';
import { toggleMute, getMuteState } from '../audio.ts';

interface HeaderProps {
  total: number;
  current: number;
  steps: number;
  pulse: boolean;
  unlockedCount?: number;
  lastDelta?: number | null;
}

function useAnimatedNumber(target: number, duration: number = 650): number {
  const [displayVal, setDisplayVal] = useState(target);
  const currentRef = useRef(target);

  useEffect(() => {
    const startVal = currentRef.current;
    if (startVal === target) return;

    const startTime = performance.now();
    let animId = 0;

    const frame = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / duration);
      // ease-out cubic for crisp, organic counting up
      const ease = 1 - Math.pow(1 - progress, 3);
      const nextVal = Math.round(startVal + (target - startVal) * ease);

      currentRef.current = nextVal;
      setDisplayVal(nextVal);

      if (progress < 1) {
        animId = requestAnimationFrame(frame);
      } else {
        currentRef.current = target;
        setDisplayVal(target);
      }
    };

    animId = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(animId);
  }, [target, duration]);

  return displayVal;
}

export const Header: React.FC<HeaderProps> = ({
  total,
  current,
  steps,
  pulse,
  unlockedCount = 0,
  lastDelta,
}) => {
  const pct = steps > 0 ? Math.min(100, Math.round(((current + 1) / steps) * 100)) : 0;
  const animatedScore = useAnimatedNumber(total);
  const currentLevel = getLevelForScore(total);
  const [isMuted, setIsMuted] = useState(getMuteState());

  const handleMuteClick = () => {
    const nextMute = toggleMute();
    setIsMuted(nextMute);
  };

  return (
    <header className="sticky top-0 z-20 border-b border-dashed border-border bg-[#fffdf7]/95 px-5 py-3 backdrop-blur shadow-xs">
      <div className="mx-auto w-full max-w-xl">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
          <div className="min-w-0">
            <p className="truncate text-xs font-bold text-accent">Answer to start earning</p>
            <div className="flex items-center gap-2">
              <p
                className={`font-mono text-2xl font-bold leading-tight text-accent tabular-nums transition-transform ${
                  pulse ? 'scale-110 text-[#be7a12]' : 'scale-100'
                }`}
              >
                <span className="align-top text-sm opacity-70">$</span>
                {animatedScore.toLocaleString('en-US')}
              </p>
              {lastDelta && lastDelta > 0 && pulse && (
                <span className="animate-pop inline-block rounded-full bg-green-100 px-2 py-0.5 text-xs font-black text-green-700 shadow-xs">
                  +${lastDelta}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleMuteClick}
              title={isMuted ? 'Unmute quiz audio' : 'Mute quiz audio'}
              aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary/80 text-sm text-foreground hover:bg-secondary cursor-pointer transition"
            >
              {isMuted ? '🔇' : '🔊'}
            </button>

            <span className="shrink-0 rounded-full bg-secondary px-3.5 py-1.5 text-xs font-semibold text-secondary-foreground shadow-xs">
              <span className={pulse ? 'inline-block animate-pop' : 'inline-block'}>
                {currentLevel.emoji}
              </span>{' '}
              {currentLevel.name}
            </span>
          </div>
        </div>

        {/* Progress Bar with Popcorn */}
        <div className="relative mt-3 h-2.5 w-full rounded-full bg-secondary overflow-visible">
          <div className="h-full overflow-hidden rounded-full">
            <div
              className="h-full rounded-full bg-gradient-accent transition-[width] duration-500 ease-out"
              style={{ width: `${pct}%` }}
            />
          </div>
          <span
            aria-hidden="true"
            className={`pointer-events-none absolute -top-2 -ml-3 text-base transition-all duration-500 ease-out select-none ${
              pulse ? 'animate-pop scale-125' : ''
            }`}
            style={{ left: `${pct}%` }}
          >
            🍿
          </span>
        </div>

        {unlockedCount > 0 && (
          <p className="mt-2 text-[11px] font-semibold text-muted-foreground flex items-center justify-between">
            <span>🎁 {unlockedCount} gift{unlockedCount > 1 ? 's' : ''} unlocked</span>
            <span>{pct}% complete</span>
          </p>
        )}
      </div>
    </header>
  );
};
